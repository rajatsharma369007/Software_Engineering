from setuptools import setup

setup(name='distribution',
      version='0.1',
      description='Gaussian distribution',
      packages=['distributions'],
      zip_safe=False)
